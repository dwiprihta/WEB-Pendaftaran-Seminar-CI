--
-- Database: `sipt`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_dosen`
--

CREATE TABLE `tbl_dosen` (
  `nidn` int(20) NOT NULL,
  `nama_dosen` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_dosen`
--

INSERT INTO `tbl_dosen` (`nidn`, `nama_dosen`) VALUES
(67897653, 'Cicilia Puji Rahayu S.Si., M.Sc.'),
(682926325, 'Agus Rianto., S.T., M.T.'),
(2147483647, 'Hendri Noviyanto., S.T, M.T');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kp`
--

CREATE TABLE `tbl_kp` (
  `npm` int(20) NOT NULL,
  `no_daftar` int(10) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `angkatan` int(4) NOT NULL,
  `smt` int(2) NOT NULL,
  `progdi` varchar(20) DEFAULT NULL,
  `tgl_awal_kp` date NOT NULL,
  `tgl_akhir_kp` date NOT NULL,
  `tempat_kp` varchar(100) DEFAULT NULL,
  `tgl_awal_konsul` date NOT NULL,
  `tgl_akhir_konsul` date NOT NULL,
  `judul_kp` varchar(100) NOT NULL,
  `dosen` varchar(60) NOT NULL,
  `periode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_kp`
--

INSERT INTO `tbl_kp` (`npm`, `no_daftar`, `nama`, `angkatan`, `smt`, `progdi`, `tgl_awal_kp`, `tgl_akhir_kp`, `tempat_kp`, `tgl_awal_konsul`, `tgl_akhir_konsul`, `judul_kp`, `dosen`, `periode`) VALUES
(201223001, 5, 'HERMAYADI', 2012, 12, 'Sistem Komputer', '2018-08-01', '2018-09-04', 'MTS MUHAMMADIYAH SIDOHARJO', '2018-10-01', '2018-10-28', 'SISTEM INFORMASI PERPUSRAKAAN DI MTS MUHAMMADIYAH SIDOHARJO SOLO', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2017/2018'),
(201323013, 4, 'BUDHIARTO', 2013, 12, 'Sistem Komputer', '2018-10-04', '2018-10-11', 'KANTOR KELURAHAN DESA KROYO', '2018-10-31', '2018-10-11', 'APLIKASI MANAJEMEN SURAT BERBASIS VB 6.0', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2015/2016'),
(201423004, 2, 'ASTUTI WULANDARI', 2014, 8, 'Sistem Komputer', '2018-11-01', '2018-11-09', 'KANTOR KELURAHAN DESA PAPAHAN', '2018-11-12', '2018-11-29', 'SISTEM INFORMASI PENGANTAR SURAT BERBASIS VB.6', 'Agus Rianto., S.T., M.T.', '2017/2018'),
(201423009, 3, 'KRISTIFORUS VINSEN MARIAN', 2014, 8, 'Sistem Komputer', '2018-11-14', '2018-11-22', 'KANTOR KELURAHAN DSA NGRINGO', '2018-11-16', '2018-11-07', 'SISTEM INFORMASI DATA PENDUDUK BERBASIS VB NET', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2017/2018'),
(201423013, 1, 'IBNU MAHFUDIN', 2014, 8, 'Sistem Komputer', '2018-11-09', '2018-11-15', 'KANTOR KELURAHAN DESA MAJENANG', '2018-11-30', '2018-11-09', 'APLIKASI SURAT PENGANTAR BERBSIS VB.60', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2017/2018'),
(1201523002, 7, 'ALPAT KUMARA', 2015, 7, 'Sistem Komputer', '2018-12-03', '2018-12-30', 'PROGRAM STUDI SISTEM KOMPUTER', '2018-12-13', '2018-12-11', 'APLIKASI ABSENSI BERBASIS VB.6', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2018/2019'),
(1201523005, 8, 'DWI PRIHTAPAMBUDIK', 2015, 8, 'Sistem Komputer', '2018-12-12', '2018-12-06', 'PROGRAM STUDI SISTEM KOMPUTER', '2018-12-06', '2018-12-11', 'SISTEM INFORMASI PENDAFTARAN SEMINAR KP', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2018/2019'),
(1201523009, 9, 'MUHAMMAD IMAM NASUHA', 2015, 7, 'Sistem Komputer', '2019-01-14', '2019-01-19', 'SRAGEN', '2019-01-12', '2019-01-18', 'SISTEM PERPUSTAKAAN TERPASU', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2016/2017'),
(1201523015, 6, 'TUTUT PRASETYO', 2015, 8, 'Sistem Komputer', '2018-11-07', '2018-11-08', 'PALUR PLAZA', '2018-11-07', '2018-11-22', 'APLIKASI STOK DATA BARANG DI PALUR PLAZA', 'Cicilia Puji Rahayu S.Si., M.Sc.', '2016/2017');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `npm` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` varchar(15) NOT NULL,
  `notif` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`npm`, `username`, `password`, `email`, `level`, `notif`) VALUES
(555, 'xx', 'xx', 'dian@gmail.com', 'admin', ''),
(1201523001, 'adi', 'adi123', 'ahok@hok.com', 'user', '<p><strong><span style="background-color:null">PENGUMUMAN</span></strong></p>\r\n\r\n<p><span style="background-color:null">1. SEMINAR AKAN DILAKSANAKN HARI SENIN JAM 2</span></p>\r\n\r\n<p><span style="background-color:null">2. DOSEN PEMBIMBING AGUS RIANTO</span></p>\r\n'),
(1201523005, 'dwi', 'dwi123', 'dwi@gmail.com', 'admin', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_dosen`
--
ALTER TABLE `tbl_dosen`
  ADD PRIMARY KEY (`nidn`);

--
-- Indexes for table `tbl_kp`
--
ALTER TABLE `tbl_kp`
  ADD PRIMARY KEY (`npm`),
  ADD KEY `pembimbing` (`dosen`),
  ADD KEY `daftar` (`no_daftar`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`npm`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_kp`
--
ALTER TABLE `tbl_kp`
  MODIFY `no_daftar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
