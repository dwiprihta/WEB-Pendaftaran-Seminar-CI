$(function() {
  $("table").tablesorter({debug: true});
});
