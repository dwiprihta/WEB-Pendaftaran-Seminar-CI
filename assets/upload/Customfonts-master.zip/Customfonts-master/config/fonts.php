<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');


$fonts['debug']		= FALSE;		// set TRUE to go to strict mode
$fonts['folder']	= 'css/fonts';	// fonts folder
$fonts['minify']	= FALSE;		// set TRUE if you want minified CSS

$fonts['fontname']['eot']			= 'fontname-webfont.eot';
$fonts['fontname']['eotie']			= 'fontname-webfont.eot?#iefix';
$fonts['fontname']['woff']			= 'fontname-webfont.woff';
$fonts['fontname']['ttf']			= 'fontname-webfont.ttf';
$fonts['fontname']['svg']			= 'fontname-webfont.svg#fontname_web_lightregular';

$fonts['fontname']['font-weight']	= 'normal';
$fonts['fontname']['font-style']	= 'normal';